#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>

// --- Definitions ---
// Right Motor
#define STEP_PIN_R 12
#define DIR_PIN_R  14
// Left Motor
#define STEP_PIN_L 27
#define DIR_PIN_L  26

// Network Credentials (Wokwi Standard)
const char* ssid = "Wokwi-GUEST";
const char* password = "";

WebServer server(80);
Adafruit_MPU6050 mpu;

// Control Variables
bool isBalancing = true; // Force it ON for testing
float targetAngle = 0.0;
float currentAngle = 0.0;
float Kp = 25.0; 

// Function Prototype
void stepMotors(int delayMicros);

// Web Page HTML
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html>
<head>
  <title>ESP32 Balancing Bot</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: Arial; text-align: center; margin-top: 50px; }
    .button { background-color: #4CAF50; border: none; color: white; padding: 15px 32px;
    text-align: center; text-decoration: none; display: inline-block; font-size: 16px; margin: 4px 2px; cursor: pointer; }
    .stop { background-color: #f44336; }
  </style>
</head>
<body>
  <h2>Self Balancing Car Control</h2>
  <p>Status: <span id="status">OFF</span></p>
  <p>Current Angle: <span id="angle">0</span></p>
  <button class="button" onclick="toggle('on')">START BALANCING</button>
  <button class="button stop" onclick="toggle('off')">STOP</button>
  <script>
    function toggle(state) {
      fetch('/' + state).then(response => {
        document.getElementById('status').innerText = state.toUpperCase();
      });
    }
    setInterval(function() {
      fetch('/readAngle').then(response => response.text()).then(data => {
        document.getElementById('angle').innerText = data;
      });
    }, 500);
  </script>
</body>
</html>
)rawliteral";

void setup() {
  Serial.begin(115200);

  // Motor Setup
  pinMode(STEP_PIN_R, OUTPUT);
  pinMode(DIR_PIN_R, OUTPUT);
  pinMode(STEP_PIN_L, OUTPUT);
  pinMode(DIR_PIN_L, OUTPUT);

  // MPU6050 Setup
  Wire.begin(21, 22);
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
    while (1) { delay(10); }
  }
  mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
  mpu.setGyroRange(MPU6050_RANGE_500_DEG);
  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);

  // WiFi Setup
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("");
  Serial.println("WiFi connected.");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());

  // Server Routes
  server.on("/", []() { server.send(200, "text/html", index_html); });
  server.on("/on", []() { isBalancing = true; server.send(200, "text/plain", "OK"); });
  server.on("/off", []() { isBalancing = false; server.send(200, "text/plain", "OK"); });
  server.on("/readAngle", []() { server.send(200, "text/plain", String(currentAngle)); });
  
  server.begin();
}

void loop() {
  server.handleClient();

  // Read Sensor
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

  currentAngle = a.acceleration.x; 

  if (isBalancing) {
    float error = targetAngle - currentAngle;
    float motorSpeed = error * Kp; 

    // Determine Direction
    if (motorSpeed > 0) {
      digitalWrite(DIR_PIN_R, HIGH); 
      digitalWrite(DIR_PIN_L, LOW);  
    } else {
      digitalWrite(DIR_PIN_R, LOW);
      digitalWrite(DIR_PIN_L, HIGH);
      motorSpeed = -motorSpeed; 
    }

    // Deadzone and Speed mapping
    if (motorSpeed > 2.0) {
        // Safe mapping logic to avoid compiler errors
        long mappedDelay = map((long)motorSpeed, 0, 10, 2000, 500);
        int finalDelay = constrain(mappedDelay, 500, 2000);
        stepMotors(finalDelay);
    }
  }
}

void stepMotors(int delayMicros) {
  digitalWrite(STEP_PIN_R, HIGH);
  digitalWrite(STEP_PIN_L, HIGH);
  delayMicroseconds(10); 
  digitalWrite(STEP_PIN_R, LOW);
  digitalWrite(STEP_PIN_L, LOW);
  delayMicroseconds(delayMicros);
}